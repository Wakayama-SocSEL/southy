import subprocess
import sys
sys.path.append('../')

#リポジトリのクローン
def clone_project(url: str):
    destination_path = f'{sys.path[-1]}/tmp'
    command = ['git', 'clone', url, destination_path]

    try:
        # サブプロセスを呼び出して git clone を実行
        subprocess.run(command, check=True)
        print(f"Repository cloned successfully to {destination_path}")
    except subprocess.CalledProcessError as e:
        print(f"Error cloning repository: {e}")