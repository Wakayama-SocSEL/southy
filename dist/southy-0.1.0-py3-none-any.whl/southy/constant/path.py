import os

ROOT = os.path.abspath("../")
DATA = f'{ROOT}/data'
TMP = f'{ROOT}/tmp'
