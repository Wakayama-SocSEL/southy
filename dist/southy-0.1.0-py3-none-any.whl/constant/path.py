import os


ROOT = os.path.abspath(os.curdir)
DATA = f'{ROOT}/data'
TMP = f'{ROOT}/tmp'
