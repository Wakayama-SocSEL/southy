import os

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '../..'))
TMP = f'{ROOT}/tmp'
ORIGIN = f'{TMP}/origin'
